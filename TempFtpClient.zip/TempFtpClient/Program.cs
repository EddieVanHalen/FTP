﻿using System.Net;
using System.Net.Sockets;

await FtpClient.Test();

public class FtpClient : IDisposable
{
    private TcpClient _client;
    private StreamReader _reader;
    private StreamWriter _writer;
    private bool _isConnected;

    public async Task Connect(string host, int port)
    {
        _client = new TcpClient();
        await _client.ConnectAsync(host, port);
        _reader = new StreamReader(_client.GetStream());
        _writer = new StreamWriter(_client.GetStream()) { AutoFlush = true };
        _isConnected = true;
        Console.WriteLine($"Connected to {host}:{port}");
    }

    public async Task<bool> Register(string username, string password)
    {
        await _writer.WriteLineAsync($"REGISTER {username} {password}");
        var response = await _reader.ReadLineAsync();
        return response == "REGISTER_SUCCESS";
    }

    public async Task<bool> Login(string username, string password)
    {
        await _writer.WriteLineAsync($"LOGIN {username} {password}");
        var response = await _reader.ReadLineAsync();
        return response == "LOGIN_SUCCESS";
    }

    public static async Task Test()
    {
        using var client = new FtpClient();

        try
        {
            await client.Connect("localhost", 2121);

            // Выбор действия
            Console.WriteLine("Choose action (register/login):");
            var action = Console.ReadLine();

            if (action == "register")
            {
                Console.Write("Username: ");
                var user = Console.ReadLine();
                Console.Write("Password: ");
                var pass = Console.ReadLine();

                if (await client.Register(user, pass))
                {
                    Console.WriteLine("Registration successful!");
                }
            }
            else if (action == "login")
            {
                Console.Write("Username: ");
                var user = Console.ReadLine();
                Console.Write("Password: ");
                var pass = Console.ReadLine();

                if (!await client.Login(user, pass))
                {
                    Console.WriteLine("Login failed");
                    return;
                }

                Console.WriteLine("Logged in!");

                while (true)
                {
                    Console.Write("ftp> ");
                    var input = Console.ReadLine().Split(' ');

                    switch (input[0].ToUpper())
                    {
                        case "LIST":
                            await client.ListFiles();
                            break;

                        case "UPLOAD":
                            await client.UploadFile(input[1], input[2]);
                            break;

                        case "DOWNLOAD":
                            await client.DownloadFile(input[1], input[2]);
                            break;

                        case "MKDIR":
                            await client.CreateDirectory(input[1]);
                            break;
                        
                        case "DELETE":
                            if (input.Length < 2)
                            {
                                Console.WriteLine("Usage: delete <path> [--force]");
                                break;
                            }
                            var force = input.Contains("--force");
                            await client.Delete(string.Join(" ", input.Skip(1).Where(x => x != "--force")), force);
                            break;


                        case "RENAME":
                            if (input.Length < 3)
                            {
                                Console.WriteLine("Usage: rename <old_name> <new_name>");
                                break;
                            }
                            await client.Rename(input[1], input[2]);
                            break;
                        
                        case "EXIT":
                            return;

                        default:
                            Console.WriteLine("Unknown command");
                            break;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }

    public async Task ListFiles()
    {
        await _writer.WriteLineAsync("LIST");
        var response = await _reader.ReadLineAsync();
        Console.WriteLine("Server files:\n" + response);
    }

    public async Task UploadFile(string localPath, string remotePath)
    {
        try
        {
            var fileInfo = new FileInfo(localPath);
            if (!fileInfo.Exists)
            {
                Console.WriteLine("File not found");
                return;
            }

            await _writer.WriteLineAsync($"UPLOAD {remotePath}");

            if (await _reader.ReadLineAsync() != "SEND_SIZE")
                throw new ProtocolViolationException("Invalid server response");

            await _writer.WriteLineAsync(fileInfo.Length.ToString());
            await _writer.FlushAsync();

            if (await _reader.ReadLineAsync() != "READY_FOR_DATA")
                throw new ProtocolViolationException("Server not ready");

            await using (var fileStream = File.OpenRead(localPath))
            {
                var buffer = new byte[4096];
                int bytesRead;

                while ((bytesRead = await fileStream.ReadAsync(buffer)) > 0)
                {
                    await _client.GetStream().WriteAsync(buffer.AsMemory(0, bytesRead));
                }
            }

            var status = await _reader.ReadLineAsync();
            Console.WriteLine(status);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Upload failed: {ex.Message}");
        }
    }

    public async Task Delete(string path, bool force = false)
    {
        try
        {
            var command = force ? $"DELETE {path} --force" : $"DELETE {path}";
            await _writer.WriteLineAsync(command);
        
            var response = await _reader.ReadLineAsync();
            Console.WriteLine(response);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Delete failed: {ex.Message}");
        }
    }

    public async Task Rename(string oldPath, string newPath)
    {
        try
        {
            await _writer.WriteLineAsync($"RENAME {oldPath} {newPath}");
            var response = await _reader.ReadLineAsync();
            Console.WriteLine(response);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Rename failed: {ex.Message}");
        }
    }


    public async Task DownloadFile(string remotePath, string localPath, int threads = 1)
    {
        try
        {
            await _writer.WriteLineAsync($"DOWNLOAD {remotePath} {threads}");
            await _writer.FlushAsync();

            var header = await _reader.ReadLineAsync();
            if (!header.StartsWith("OK:"))
            {
                Console.WriteLine("Error: " + header);
                return;
            }

            var parts = header.Split(':');
            var fileSize = long.Parse(parts[1]);
            var receivedBytes = 0L;

            await using (var fileStream = new FileStream(
                             localPath,
                             FileMode.Create,
                             FileAccess.Write,
                             FileShare.None,
                             81920,
                             FileOptions.SequentialScan))
            {
                var buffer = new byte[81920];

                while (receivedBytes < fileSize)
                {
                    var bytesToRead = (int)Math.Min(buffer.Length, fileSize - receivedBytes);
                    var bytesRead = await _client.GetStream().ReadAsync(buffer, 0, bytesToRead);

                    if (bytesRead == 0)
                    {
                        throw new EndOfStreamException("Connection Closed Before End Of Receiving");
                    }

                    await fileStream.WriteAsync(buffer.AsMemory(0, bytesRead));
                    receivedBytes += bytesRead;
                }
            }

            var finalStatus = await _reader.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(5));
            Console.WriteLine(finalStatus);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Loading Error: {ex.Message}");
            if (File.Exists(localPath)) File.Delete(localPath);
        }
    }

    public async Task CreateDirectory(string dirName)
    {
        await _writer.WriteLineAsync($"MKDIR {dirName}");
        Console.WriteLine(await _reader.ReadLineAsync());
    }

    public void Dispose()
    {
        _isConnected = false;
        _reader?.Dispose();
        _writer?.Dispose();
        _client?.Dispose();
    }
}