﻿using var server = new FtpServer.FtpServer();
server.Start(2121);