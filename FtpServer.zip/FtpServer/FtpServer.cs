using System.Net;
using System.Net.Sockets;
using System.Security;
using System.Security.Cryptography;
using System.Text;

namespace FtpServer;

public class FtpServer : IDisposable
{
    private TcpListener _listener;
    private readonly AppDbContext _dbContext;
    private readonly string _basePath = Path.Combine(Directory.GetCurrentDirectory(), "UserStorage");
    private bool _isRunning;

    public FtpServer()
    {
        _dbContext = new AppDbContext();
        Directory.CreateDirectory(_basePath);
    }

    public void Start(int port)
    {
        _isRunning = true;
        _listener = new TcpListener(IPAddress.Any, port);
        _listener.Start();
        Console.WriteLine($"FTP Server started on port {port}");

        while (_isRunning)
        {
            var client = _listener.AcceptTcpClient();
            Task.Run(() => HandleClient(client));
        }
    }

    private async Task HandleClient(TcpClient client)
    {
        using (client)
        using (var stream = client.GetStream())
        {
            var reader = new StreamReader(stream);
            var writer = new StreamWriter(stream) { AutoFlush = true };
            User currentUser = null;

            try
            {
                var actionLine = await reader.ReadLineAsync();
                var actionParts = actionLine.Split(' ');

                switch (actionParts[0].ToUpper())
                {
                    case "REGISTER":
                        await HandleRegister(actionParts[1], actionParts[2], writer);
                        break;

                    case "LOGIN":
                        currentUser = await HandleLogin(actionParts[1], actionParts[2], writer);
                        break;

                    default:
                        await writer.WriteLineAsync("ERROR: Invalid initial command");
                        return;
                }

                if (currentUser != null)
                {
                    await CommandLoop(currentUser, reader, writer);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Client error: {ex.Message}");
            }
        }
    }

    private async Task<User> HandleLogin(string username, string password, StreamWriter writer)
    {
        var user = AuthenticateUser(username, password);
        if (user == null)
        {
            await writer.WriteLineAsync("LOGIN_FAILED");
            return null;
        }

        await writer.WriteLineAsync("LOGIN_SUCCESS");
        return user;
    }

    private async Task HandleRegister(string username, string password, StreamWriter writer)
    {
        if (_dbContext.Users.Any(u => u.Username == username))
        {
            await writer.WriteLineAsync("ERROR: Username already exists");
            return;
        }

        var user = new User
        {
            Username = username,
            PasswordHash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(password))),
            RootDirectory = Path.Combine(_basePath, username)
        };

        Directory.CreateDirectory(user.RootDirectory);
        _dbContext.Users.Add(user);
        await _dbContext.SaveChangesAsync();

        await writer.WriteLineAsync("REGISTER_SUCCESS");
    }

    private async Task CommandLoop(User user, StreamReader reader, StreamWriter writer)
    {
        while (true)
        {
            var commandLine = await reader.ReadLineAsync();
            if (string.IsNullOrEmpty(commandLine)) break;

            var parts = commandLine.Split(' ');
            var command = parts[0].ToUpper();
            var args = parts.Skip(1).ToArray();

            try
            {
                switch (command)
                {
                    case "LIST":
                        await HandleList(user, writer);
                        break;
                    case "MKDIR":
                        await HandleMkdir(user, args[0], writer);
                        break;
                    case "UPLOAD":
                        await HandleUpload(user, args[0], reader, writer);
                        break;
                    case "DOWNLOAD":
                        await HandleDownload(user, args[0], int.Parse(args[1]), writer);
                        break;
                    case "RENAME":
                        await HandleRename(user, args[0], args[1], writer);
                        break;
                    case "DELETE":
                        await HandleDelete(user, args, writer);
                        break;
                    case "COPY":
                        await HandleCopy(user, args[0], writer);
                        break;
                    case "REGISTER":
                        await HandleRegister(args[0], args[1], writer);
                        break;
                    default:
                        await writer.WriteLineAsync("ERROR: Unknown command");
                        break;
                }
            }
            catch (Exception ex)
            {
                await writer.WriteLineAsync($"ERROR: {ex.Message}");
            }
        }
    }

    #region Command Handlers

    private async Task HandleList(User user, StreamWriter writer)
    {
        var path = GetUserPath(user, "");
        var dirInfo = new DirectoryInfo(path);

        var response = new StringBuilder();
        foreach (var dir in dirInfo.GetDirectories())
            response.AppendLine($"[DIR] {dir.Name}");

        foreach (var file in dirInfo.GetFiles())
            response.AppendLine($"[FILE] {file.Name} {file.Length} bytes");

        await writer.WriteLineAsync(response.ToString());
    }

    private async Task HandleMkdir(User user, string dirName, StreamWriter writer)
    {
        var path = GetUserPath(user, dirName);
        Directory.CreateDirectory(path);
        await writer.WriteLineAsync("OK: Directory created");
    }

    private async Task HandleUpload(User user, string fileName, StreamReader reader, StreamWriter writer)
    {
        var filePath = GetUserPath(user, fileName);
        long totalReceived = 0;
        long fileSize = 0;

        try
        {
            await writer.WriteLineAsync("SEND_SIZE");
            var sizeLine = await reader.ReadLineAsync();

            if (!long.TryParse(sizeLine, out fileSize) || fileSize <= 0)
            {
                await writer.WriteLineAsync("ERROR: Invalid file size format");
                return;
            }

            await writer.WriteLineAsync("READY_FOR_DATA");
            await writer.FlushAsync();

            await using var fileStream = new FileStream(
                filePath,
                FileMode.Create,
                FileAccess.Write,
                FileShare.None,
                4096,
                FileOptions.Asynchronous
            );

            var buffer = new byte[4096];
            long remaining = fileSize;

            while (remaining > 0)
            {
                var bytesToRead = (int)Math.Min(buffer.Length, remaining);
                var bytesRead = await reader.BaseStream.ReadAsync(buffer, 0, bytesToRead);

                if (bytesRead == 0)
                    throw new EndOfStreamException("Connection closed prematurely");

                await fileStream.WriteAsync(buffer.AsMemory(0, bytesRead));
                remaining -= bytesRead;
                totalReceived += bytesRead;
            }

            await writer.WriteLineAsync($"OK: Received {totalReceived} bytes");
            Console.WriteLine($"File {fileName} uploaded successfully");
        }
        catch (Exception ex)
        {
            if (File.Exists(filePath)) File.Delete(filePath);
            await writer.WriteLineAsync($"ERROR: {ex.GetType().Name}: {ex.Message}");
            Console.WriteLine($"Upload failed: {ex.Message}");
        }
    }

    private async Task HandleDownload(User user, string fileName, int threads, StreamWriter writer)
    {
        var filePath = GetUserPath(user, fileName);
        var fileInfo = new FileInfo(filePath);

        try
        {
            if (!fileInfo.Exists)
            {
                await writer.WriteLineAsync("ERROR: File not found");
                return;
            }

            await writer.WriteLineAsync($"OK:{fileInfo.Length}:{threads}");
            await writer.FlushAsync();

            if (threads > 1)
            {
                await DownloadMultithreaded(fileInfo, threads, writer);
            }
            else
            {
                await DownloadSingleThreaded(fileInfo, writer);
            }

            await writer.WriteLineAsync("DOWNLOAD_COMPLETE");
        }
        catch (Exception ex)
        {
            await writer.WriteLineAsync($"ERROR: {ex.Message}");
        }
    }

    private async Task DownloadSingleThreaded(FileInfo fileInfo, StreamWriter writer)
    {
        await using var fileStream = fileInfo.OpenRead();
        var buffer = new byte[81920];
        int bytesRead;

        while ((bytesRead = await fileStream.ReadAsync(buffer)) > 0)
        {
            await writer.BaseStream.WriteAsync(buffer.AsMemory(0, bytesRead));
        }
    }

    private async Task DownloadMultithreaded(FileInfo fileInfo, int threads, StreamWriter writer)
    {
        var chunkSize = fileInfo.Length / threads;
        var tasks = new List<Task>();
        var lockObject = new object();

        for (int i = 0; i < threads; i++)
        {
            var chunkNumber = i;
            tasks.Add(Task.Run(async () =>
            {
                await using var fs = new FileStream(
                    fileInfo.FullName,
                    FileMode.Open,
                    FileAccess.Read,
                    FileShare.Read,
                    4096,
                    FileOptions.Asynchronous
                );

                var start = chunkNumber * chunkSize;
                var end = (chunkNumber == threads - 1) ? fileInfo.Length : start + chunkSize;
                var length = end - start;

                fs.Seek(start, SeekOrigin.Begin);

                var buffer = new byte[81920];
                long totalRead = 0;

                while (totalRead < length)
                {
                    var bytesToRead = (int)Math.Min(buffer.Length, length - totalRead);
                    var bytesRead = await fs.ReadAsync(buffer, 0, bytesToRead);

                    var chunkHeader = $"CHUNK:{chunkNumber}:{bytesRead}";
                    var headerData = Encoding.UTF8.GetBytes(chunkHeader);

                    lock (lockObject)
                    {
                        writer.BaseStream.Write(headerData, 0, headerData.Length);
                        writer.BaseStream.Write(buffer, 0, bytesRead);
                    }

                    totalRead += bytesRead;
                }
            }));
        }

        await Task.WhenAll(tasks);
    }

    private async Task HandleRename(User user, string oldName, string newName, StreamWriter writer)
    {
        try
        {
            var oldPath = GetUserPath(user, oldName);
            var newPath = GetUserPath(user, newName);

            if (oldPath.Equals(user.RootDirectory, StringComparison.OrdinalIgnoreCase))
            {
                throw new SecurityException("Cannot rename root directory");
            }

            if (string.IsNullOrWhiteSpace(newName) || newName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
            {
                throw new ArgumentException("Invalid new name");
            }

            if (!File.Exists(oldPath) && !Directory.Exists(oldPath))
            {
                throw new FileNotFoundException("Source path not found");
            }

            if (File.Exists(newPath) || Directory.Exists(newPath))
            {
                throw new IOException("Target path already exists");
            }

            if (File.Exists(oldPath))
            {
                File.Move(oldPath, newPath);
            }
            else
            {
                Directory.Move(oldPath, newPath);
            }

            await writer.WriteLineAsync("OK: Rename successful");
        }
        catch (Exception ex)
        {
            await writer.WriteLineAsync($"ERROR: {ex.GetType().Name}: {ex.Message}");
            Console.WriteLine($"Rename failed: {ex.Message}");
        }
    }

    
    private async Task HandleDelete(User user, string[] args, StreamWriter writer)
    {
        try
        {
            var path = args[0];
            var force = args.Contains("--force");

            var fullPath = GetUserPath(user, path);

            if (fullPath.Equals(user.RootDirectory, StringComparison.OrdinalIgnoreCase))
                throw new SecurityException("Cannot delete root directory");

            if (!File.Exists(fullPath) && !Directory.Exists(fullPath))
                throw new FileNotFoundException("Path not found");

            if (File.Exists(fullPath))
            {
                File.Delete(fullPath);
                await writer.WriteLineAsync("OK: File deleted");
                return;
            }

            if (force)
            {
                Directory.Delete(fullPath, recursive: true);
                await writer.WriteLineAsync("OK: Directory deleted (forced)");
            }
            else
            {
                if (Directory.GetFileSystemEntries(fullPath).Length > 0)
                    throw new IOException("Directory not empty. Use --force");
            
                Directory.Delete(fullPath);
                await writer.WriteLineAsync("OK: Directory deleted");
            }
        }
        catch (Exception ex)
        {
            await writer.WriteLineAsync($"ERROR: {ex.GetType().Name}: {ex.Message}");
        }
    }

    private async Task HandleCopy(User user, string fileName, StreamWriter writer)
    {
        var sourcePath = GetUserPath(user, fileName);
        var copyPath = GenerateCopyName(sourcePath);

        File.Copy(sourcePath, copyPath);
        await writer.WriteLineAsync($"OK: Copied to {Path.GetFileName(copyPath)}");
    }

    #endregion

    #region Helper Methods

    private User AuthenticateUser(string username, string password)
    {
        var user = _dbContext.Users
            .FirstOrDefault(u => u.Username == username);

        if (user == null || !VerifyPassword(password, user.PasswordHash))
            return null;

        return user;
    }

    private bool VerifyPassword(string password, string storedHash)
    {
        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(password)));
        return hash == storedHash;
    }

    private string GetUserPath(User user, string relativePath)
    {
        var fullPath = Path.Combine(user.RootDirectory, relativePath);

        if (!Path.GetFullPath(fullPath).StartsWith(user.RootDirectory))
            throw new SecurityException("Invalid path");

        return fullPath;
    }

    private string GenerateCopyName(string originalPath)
    {
        var dir = Path.GetDirectoryName(originalPath);
        var fileName = Path.GetFileNameWithoutExtension(originalPath);
        var ext = Path.GetExtension(originalPath);
        var counter = 1;

        string newPath;
        do
        {
            newPath = Path.Combine(dir, $"{fileName}_{counter++}{ext}");
        } while (File.Exists(newPath));

        return newPath;
    }

    #endregion

    public void Dispose()
    {
        _isRunning = false;
        _listener?.Stop();
        _dbContext.Dispose();
    }
}